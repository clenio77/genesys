"""
Bot de Telegram Jurídico - Genesys Tecnologia
"""

__version__ = "1.0.0"

