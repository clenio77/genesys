"""
Módulo compartilhado do Tier 1
"""

