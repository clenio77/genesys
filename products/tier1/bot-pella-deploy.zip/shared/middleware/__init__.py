"""Middleware compartilhado para todos os produtos"""

