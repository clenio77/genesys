"""
Configurações compartilhadas
"""

