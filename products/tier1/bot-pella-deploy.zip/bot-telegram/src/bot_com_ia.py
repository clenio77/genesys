"""
Bot com IA integrada para respostas inteligentes
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters
from shared.config.settings import settings
from shared.utils.logger import bot_telegram_logger as logger

# Importar serviço de IA
from services.ia_service import ai_service
from services.database_service import db_service


# Importar handlers completos com indicadores UX
from handlers.messages import handle_message as text_handler


async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler para /start com indicador de digitação"""
    # Mostrar indicador de digitação (de forma segura)
    try:
        await update.message.chat.send_action("typing")
    except Exception:
        pass  # Ignorar timeouts - não é crítico
    
    # Criar/buscar usuário
    try:
        user = update.effective_user
        db_service.get_or_create_user(user.id, user.username or "User", user.full_name or "User")
    except:
        pass
    
    await update.message.reply_text(
        "🤖 **Bem-vindo ao Genesys Bot Jurídico!**\n\n"
        "Posso ajudá-lo com:\n"
        "• 🧠 Consultas jurídicas com IA\n"
        "• 🔍 Busca de jurisprudência\n"
        "• 📅 Controle de prazos processuais\n"
        "• 🔔 Alertas automáticos\n"
        "• ⚖️ Consulta de processos (API CNJ + base local)\n"
        "• 👨‍⚖️ Perfis de magistrados\n\n"
        "**Comandos:**\n"
        "• /start - Reiniciar bot\n"
        "• /help - Ver ajuda completa\n"
        "• /buscar - Buscar jurisprudência\n"
        "• /prazos - Ver prazos pendentes\n"
        "• /alerta - Configurar alertas\n"
        "• /processo - Consultar processo\n"
        "• /magistrado - Buscar magistrado\n\n"
        "💬 Envie uma mensagem para conversar com IA!",
        parse_mode="Markdown"
    )


def main():
    """Função principal"""
    logger.info("🤖 Iniciando Bot de Telegram com IA...")
    
    if not settings.TELEGRAM_BOT_TOKEN or settings.TELEGRAM_BOT_TOKEN == "your_telegram_bot_token_here":
        logger.error("❌ TELEGRAM_BOT_TOKEN não configurado!")
        return
    
    # Criar aplicação
    application = Application.builder().token(settings.TELEGRAM_BOT_TOKEN).build()
    
    # Registrar comando /start com indicador UX
    application.add_handler(CommandHandler("start", start_handler))
    logger.info("✅ Comando /start registrado")
    
    # Importar e registrar todos os outros comandos
    try:
        from handlers.commands import register_command_handlers
        register_command_handlers(application)
        logger.info("✅ Todos os comandos registrados")
    except Exception as e:
        logger.error(f"Erro ao registrar comandos: {e}")
    
    # Message handler deve vir por último
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_handler))
    logger.info("✅ Handler de mensagens registrado")
    
    logger.info("✅ Bot com IA iniciado! Aguardando mensagens...")
    
    # Rodar
    application.run_polling(
        allowed_updates=Update.ALL_TYPES,
        drop_pending_updates=True
    )


if __name__ == "__main__":
    main()

