"""
Serviço para acessar dados do Kermartin
Permite consultar processos, magistrados e promotores já coletados
"""

import sys
import json
import sqlite3
from pathlib import Path
from typing import Optional, Dict, List
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from shared.utils.logger import bot_telegram_logger as logger

# Caminho base do Kermartin
KERMARTIN_BASE = Path("/home/clenio/Documentos/Meusagentes/kermartin")
KERMARTIN_DB = KERMARTIN_BASE / "db.sqlite3"
KERMARTIN_KB = KERMARTIN_BASE / "knowledge_base"
KERMARTIN_DATA = KERMARTIN_BASE / "data"


class KermartinService:
    """Serviço para acessar dados coletados no Kermartin"""
    
    def __init__(self):
        self.base_path = KERMARTIN_BASE
        self.db_path = KERMARTIN_DB
        self.kb_path = KERMARTIN_KB
        self.data_path = KERMARTIN_DATA
        
        # Verificar se caminhos existem
        if not self.base_path.exists():
            logger.warning(f"Caminho do Kermartin não encontrado: {self.base_path}")
        else:
            logger.info(f"✅ Serviço Kermartin inicializado: {self.base_path}")
    
    def _normalizar_nome(self, nome: str) -> str:
        """
        Normaliza nome para comparação:
        - Remove acentos
        - Converte para minúsculas
        - Remove espaços extras
        """
        import unicodedata
        # Converter para minúsculas e remover espaços extras
        nome = nome.lower().strip()
        # Remover acentos
        nome = unicodedata.normalize('NFD', nome)
        nome = ''.join(char for char in nome if unicodedata.category(char) != 'Mn')
        return nome
    
    def _buscar_nome_em_dados(self, nome_busca: str, dados: Dict) -> bool:
        """
        Busca nome normalizado em vários campos do magistrado
        """
        nome_busca_norm = self._normalizar_nome(nome_busca)
        
        # Campos possíveis onde o nome pode estar
        campos_nome = [
            dados.get('dados', {}).get('magistrado'),
            dados.get('metadata', {}).get('nome_magistrado'),
            dados.get('nome_publico'),
            dados.get('nome'),
        ]
        
        # Também verificar o nome do arquivo (já normalizado no loop)
        arquivo_nome = dados.get('_arquivo_nome', '')
        
        for campo in campos_nome:
            if campo:
                campo_norm = self._normalizar_nome(str(campo))
                # Busca exata ou parcial
                if nome_busca_norm == campo_norm or nome_busca_norm in campo_norm or campo_norm in nome_busca_norm:
                    return True
        
        # Verificar também no nome do arquivo
        if arquivo_nome:
            arquivo_norm = self._normalizar_nome(arquivo_nome)
            if nome_busca_norm in arquivo_norm or arquivo_norm in nome_busca_norm:
                return True
        
        return False
    
    def buscar_magistrado(self, nome: str) -> Optional[Dict]:
        """
        Busca perfil de magistrado na base de conhecimento
        
        Args:
            nome: Nome do magistrado (pode ser parcial, case-insensitive)
            
        Returns:
            Dict com dados do magistrado ou None
        """
        try:
            magistrados_path = self.kb_path / "magistrados"
            
            if not magistrados_path.exists():
                logger.warning("Diretório de magistrados não encontrado")
                return None
            
            # Normalizar nome de busca
            nome_busca_norm = self._normalizar_nome(nome)
            logger.info(f"Buscando magistrado: '{nome}' (normalizado: '{nome_busca_norm}')")
            
            # Lista para armazenar correspondências (pode ter múltiplas)
            correspondencias = []
            
            for arquivo in magistrados_path.glob("*.json"):
                try:
                    with open(arquivo, 'r', encoding='utf-8') as f:
                        dados = json.load(f)
                    
                    # Adicionar nome do arquivo aos dados para busca
                    dados['_arquivo_nome'] = arquivo.stem
                    
                    # Verificar se nome corresponde
                    if self._buscar_nome_em_dados(nome, dados):
                        logger.info(f"✅ Magistrado encontrado: {arquivo.stem}")
                        correspondencias.append((arquivo.stem, dados))
                        
                except Exception as e:
                    logger.warning(f"Erro ao ler {arquivo}: {e}")
                    continue
            
            if correspondencias:
                # Se múltiplas correspondências, retornar a primeira (mais completa)
                # Ou a que tem o nome mais exato
                melhor_match = correspondencias[0][1]
                
                # Se tiver mais de uma, tentar encontrar a melhor correspondência
                if len(correspondencias) > 1:
                    for nome_arquivo, dados_match in correspondencias:
                        nome_magistrado = self._normalizar_nome(
                            dados_match.get('dados', {}).get('magistrado') or 
                            dados_match.get('metadata', {}).get('nome_magistrado') or 
                            nome_arquivo
                        )
                        # Priorizar correspondências exatas
                        if nome_busca_norm == nome_magistrado:
                            melhor_match = dados_match
                            logger.info(f"Melhor match encontrado: {nome_arquivo}")
                            break
                
                return melhor_match
            
            logger.info(f"Magistrado '{nome}' não encontrado na base")
            return None
            
        except Exception as e:
            logger.error(f"Erro ao buscar magistrado: {e}")
            return None
    
    def buscar_promotor(self, nome: str) -> Optional[Dict]:
        """
        Busca perfil de promotor na base de conhecimento
        """
        try:
            promotores_path = self.kb_path / "promotores"
            
            if not promotores_path.exists():
                return None
            
            nome_lower = nome.lower().strip()
            
            for arquivo in promotores_path.glob("*.json"):
                try:
                    with open(arquivo, 'r', encoding='utf-8') as f:
                        dados = json.load(f)
                    
                    nome_promotor = dados.get('nome', '').lower()
                    nome_arquivo = arquivo.stem.lower()
                    
                    if nome_lower in nome_promotor or nome_lower in nome_arquivo:
                        logger.info(f"Promotor encontrado: {arquivo.stem}")
                        return dados
                        
                except Exception as e:
                    continue
            
            return None
            
        except Exception as e:
            logger.error(f"Erro ao buscar promotor: {e}")
            return None
    
    def buscar_processos_por_comarca(self, comarca: str) -> List[Dict]:
        """
        Busca processos coletados por comarca
        
        Args:
            comarca: Nome da comarca (ex: "Uberlândia")
            
        Returns:
            Lista de processos encontrados
        """
        try:
            processos = []
            
            # Buscar em data/triangulo_mineiro/processos/
            triangulo_path = self.data_path / "triangulo_mineiro" / "processos"
            
            if triangulo_path.exists():
                for arquivo in triangulo_path.glob("*.json"):
                    try:
                        with open(arquivo, 'r', encoding='utf-8') as f:
                            dados = json.load(f)
                        
                        # Se for lista, processar cada item
                        if isinstance(dados, list):
                            for processo in dados:
                                if isinstance(processo, dict):
                                    if comarca.lower() in str(processo.get('comarca', '')).lower():
                                        processos.append(processo)
                        elif isinstance(dados, dict):
                            if comarca.lower() in str(dados.get('comarca', '')).lower():
                                processos.append(dados)
                                
                    except Exception as e:
                        continue
            
            logger.info(f"Encontrados {len(processos)} processos para {comarca}")
            return processos
            
        except Exception as e:
            logger.error(f"Erro ao buscar processos: {e}")
            return []
    
    def consultar_db_django(self, query: str, params: tuple = ()) -> List[Dict]:
        """
        Consulta direta no banco SQLite do Django
        
        Args:
            query: SQL query
            params: Parâmetros da query
            
        Returns:
            Lista de resultados
        """
        try:
            if not self.db_path.exists():
                logger.warning("Banco de dados do Kermartin não encontrado")
                return []
            
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row  # Retornar como dict
            cursor = conn.cursor()
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            # Converter para lista de dicts
            resultados = [dict(row) for row in rows]
            
            conn.close()
            return resultados
            
        except Exception as e:
            logger.error(f"Erro ao consultar banco: {e}")
            return []
    
    def buscar_processos_rag(self, filtro: Dict) -> List[Dict]:
        """
        Busca processos na base RAG do Django
        
        Args:
            filtro: Dict com filtros (tribunal, comarca, tipo, etc.)
            
        Returns:
            Lista de processos
        """
        try:
            # Construir query base
            query = "SELECT * FROM ai_engine_ragknowledgebase WHERE 1=1"
            params = []
            
            # Adicionar filtros
            if filtro.get('tribunal'):
                query += " AND metadata_json LIKE ?"
                params.append(f'%"tribunal":"{filtro["tribunal"]}%')
            
            if filtro.get('comarca'):
                query += " AND metadata_json LIKE ?"
                params.append(f'%"comarca":"{filtro["comarca"]}%')
            
            query += " LIMIT 50"  # Limitar resultados
            
            return self.consultar_db_django(query, tuple(params))
            
        except Exception as e:
            logger.error(f"Erro ao buscar processos RAG: {e}")
            return []
    
    def buscar_processo_por_numero(self, numero_cnj: str) -> Optional[Dict]:
        """
        Busca processo específico por número CNJ
        
        Args:
            numero_cnj: Número do processo no formato CNJ
            
        Returns:
            Dict com dados do processo ou None
        """
        try:
            # Limpar número (remover pontos e hífens para busca)
            numero_limpo = numero_cnj.replace('-', '').replace('.', '').strip()
            
            # 1. PRIORIDADE: Buscar em julgados de magistrados (melhor qualidade de dados)
            magistrados_path = self.kb_path / "magistrados"
            
            if magistrados_path.exists():
                logger.info(f"Buscando em julgados de magistrados (prioridade)...")
                for arquivo in magistrados_path.glob("*.json"):
                    try:
                        with open(arquivo, 'r', encoding='utf-8') as f:
                            dados = json.load(f)
                        
                        # Procurar nos julgados
                        julgados = dados.get('dados', {}).get('julgados_consolidados', [])
                        
                        for julgado in julgados:
                            numero_julgado = str(julgado.get('numero', '')).strip()
                            numero_julgado_limpo = numero_julgado.replace('-', '').replace('.', '').strip()
                            
                            # Comparar de múltiplas formas
                            if (numero_cnj == numero_julgado or 
                                numero_limpo == numero_julgado_limpo or
                                numero_limpo in numero_julgado_limpo):
                                
                                logger.info(f"✅ Processo encontrado em julgado do magistrado: {arquivo.stem}")
                                processo_formatado = self._formatar_julgado_como_processo(julgado, dados)
                                return processo_formatado
                                
                    except Exception as e:
                        logger.debug(f"Erro ao ler {arquivo}: {e}")
                        continue
            
            # 2. Buscar em arquivos JSON de dados coletados
            triangulo_path = self.data_path / "triangulo_mineiro" / "processos"
            
            if triangulo_path.exists():
                for arquivo in triangulo_path.glob("*.json"):
                    try:
                        with open(arquivo, 'r', encoding='utf-8') as f:
                            dados = json.load(f)
                        
                        # Se for lista
                        if isinstance(dados, list):
                            for proc in dados:
                                numero_proc = str(proc.get('numero', '')).replace('-', '').replace('.', '')
                                if numero_limpo in numero_proc:
                                    logger.info(f"Processo encontrado em JSON: {numero_cnj}")
                                    return proc
                        # Se for dict único
                        elif isinstance(dados, dict):
                            numero_proc = str(dados.get('numero', '')).replace('-', '').replace('.', '')
                            if numero_limpo in numero_proc:
                                logger.info(f"Processo encontrado em JSON: {numero_cnj}")
                                return dados
                                
                    except Exception as e:
                        continue
            
            # 3. FALLBACK: Tentar buscar na base RAG (pode ter dados parciais)
            processos_rag = self.buscar_processos_rag({'numero': numero_cnj})
            
            for processo in processos_rag:
                # Verificar se o número está no content (não confiar apenas no metadata)
                content = str(processo.get('content', ''))
                if numero_cnj in content or numero_limpo in content.replace('-', '').replace('.', ''):
                    logger.info(f"Processo encontrado na base RAG: {numero_cnj}")
                    processo_formatado = self._formatar_processo_rag(processo)
                    # Extrair número correto do content se metadata estiver errado
                    if numero_cnj in content:
                        processo_formatado['numero'] = numero_cnj
                    return processo_formatado
            
            logger.info(f"Processo {numero_cnj} não encontrado no Kermartin")
            return None
            
        except Exception as e:
            logger.error(f"Erro ao buscar processo por número: {e}")
            return None
    
    def _formatar_processo_rag(self, processo_rag: Dict) -> Dict:
        """Formata processo da base RAG para formato padrão, extraindo dados do content"""
        try:
            content = processo_rag.get('content', '')
            
            # Tentar extrair dados do content (markdown) se metadata não tiver
            import re
            
            # Extrair número do processo do content
            numero_match = re.search(r'Processo[:\s]*(\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4})', content, re.IGNORECASE)
            numero = numero_match.group(1) if numero_match else None
            
            # Extrair vara
            vara_match = re.search(r'Vara[:\s]*([^\n]+)', content, re.IGNORECASE)
            vara = vara_match.group(1).strip() if vara_match else None
            
            # Extrair tribunal
            tribunal_match = re.search(r'Tribunal[:\s]*([^\n]+)', content, re.IGNORECASE)
            tribunal = tribunal_match.group(1).strip() if tribunal_match else None
            
            # Extrair data
            data_match = re.search(r'Data[:\s]*(\d{4}-\d{2}-\d{2})', content, re.IGNORECASE)
            data = data_match.group(1) if data_match else None
            
            # Extrair confiabilidade
            conf_match = re.search(r'Confiabilidade[:\s]*(\w+)', content, re.IGNORECASE)
            confiabilidade = conf_match.group(1).strip() if conf_match else None
            
            # Tentar metadata também
            metadata = {}
            try:
                metadata_json_str = processo_rag.get('metadata_json', '{}')
                metadata = json.loads(metadata_json_str) if isinstance(metadata_json_str, str) else metadata_json_str
            except Exception:
                pass
            
            return {
                'numero': numero or metadata.get('numero', processo_rag.get('id', 'N/A')),
                'classe': metadata.get('classe', 'Processo Judicial'),
                'assunto': metadata.get('assunto', ''),
                'tribunal': tribunal or metadata.get('tribunal', 'N/A'),
                'vara': vara or metadata.get('vara', 'N/A'),
                'status': metadata.get('status', 'Julgado' if 'julgado' in content.lower() else 'N/A'),
                'data_autuacao': data or metadata.get('data_autuacao', ''),
                'confiabilidade': confiabilidade or metadata.get('confiabilidade', ''),
                'movimentacoes': metadata.get('movimentacoes', []),
                'fonte': 'Kermartin RAG',
                'content': content
            }
        except Exception as e:
            logger.error(f"Erro ao formatar processo RAG: {e}")
            return processo_rag
    
    def _formatar_julgado_como_processo(self, julgado: Dict, dados_magistrado: Dict) -> Dict:
        """Formata julgado como se fosse um processo"""
        return {
            'numero': julgado.get('numero', 'N/A'),
            'classe': 'Processo Judicial',
            'assunto': julgado.get('ementa', ''),
            'tribunal': julgado.get('tribunal', dados_magistrado.get('metadata', {}).get('tribunal', 'N/A')),
            'vara': julgado.get('vara', 'N/A'),
            'status': 'Julgado',
            'data_autuacao': julgado.get('data', ''),
            'magistrado': julgado.get('relator', dados_magistrado.get('dados', {}).get('magistrado', '')),
            'promotor': julgado.get('promotor', ''),
            'decisao': julgado.get('decisao', ''),
            'confiabilidade': julgado.get('confiabilidade', ''),
            'arquivo_origem': julgado.get('arquivo_origem', ''),
            'fonte': julgado.get('fonte', 'Kermartin - Julgado de Magistrado'),
            'movimentacoes': []
        }
    
    def listar_magistrados_disponiveis(self, comarca: str = None) -> List[str]:
        """
        Lista todos os magistrados disponíveis na base
        
        Args:
            comarca: Filtrar por comarca (opcional)
            
        Returns:
            Lista de nomes de magistrados
        """
        try:
            magistrados = []
            magistrados_path = self.kb_path / "magistrados"
            
            if not magistrados_path.exists():
                return []
            
            for arquivo in magistrados_path.glob("*.json"):
                try:
                    with open(arquivo, 'r', encoding='utf-8') as f:
                        dados = json.load(f)
                    
                    nome = dados.get('dados', {}).get('magistrado') or dados.get('metadata', {}).get('nome_magistrado') or dados.get('nome_publico') or arquivo.stem
                    
                    # Filtrar por comarca se especificado
                    if comarca:
                        comarca_magistrado = str(dados.get('comarca', '') or dados.get('dados', {}).get('comarca', '')).lower()
                        if comarca.lower() not in comarca_magistrado:
                            continue
                    
                    # Adicionar nome normalizado para evitar duplicatas
                    if nome:
                        nome_normalizado = self._normalizar_nome(nome)
                        # Verificar se já existe (comparando normalizados)
                        existe = any(self._normalizar_nome(existente) == nome_normalizado for existente in magistrados)
                        if not existe:
                            magistrados.append(nome)
                    
                except:
                    continue
            
            return sorted(set(magistrados))
            
        except Exception as e:
            logger.error(f"Erro ao listar magistrados: {e}")
            return []


# Instância global
kermartin_service = KermartinService()

