"""
Serviço de IA para processar mensagens e gerar respostas
"""

import sys
from pathlib import Path
from typing import Optional, Dict, List
from abc import ABC, abstractmethod

# Adiciona o diretório pai ao path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from shared.config.settings import settings
from shared.utils.logger import bot_telegram_logger as logger


class AIProvider(ABC):
    """Interface para provedores de IA"""
    
    @abstractmethod
    async def generate_response(self, message: str, context: Optional[Dict] = None) -> str:
        """Gera resposta para uma mensagem"""
        pass


class OpenAIProvider(AIProvider):
    """Provedor OpenAI GPT"""
    
    def __init__(self):
        self.api_key = settings.OPENAI_API_KEY
        if not self.api_key:
            logger.warning("OPENAI_API_KEY não configurado")
    
    async def generate_response(self, message: str, context: Optional[Dict] = None) -> str:
        """Gera resposta usando OpenAI"""
        try:
            from openai import AsyncOpenAI
            client = AsyncOpenAI(api_key=self.api_key)
            
            system_prompt = """Você é um assistente jurídico especializado da Genesys Tecnologia.
            Forneça respostas precisas, educadas e profissionais sobre questões jurídicas brasileiras.
            Se não tiver certeza, admita e recomende consultar um advogado.
            Seja conciso e objetivo nas respostas."""
            
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": message}
            ]
            
            response = await client.chat.completions.create(
                model="gpt-4o-mini",
                messages=messages,
                temperature=0.7,
                max_tokens=500
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Erro ao chamar OpenAI: {e}")
            return self._fallback_response(message)
    
    def _fallback_response(self, message: str) -> str:
        """Resposta fallback quando OpenAI falha"""
        return "⚠️ No momento estou tendo dificuldades técnicas. Por favor, tente novamente ou use os comandos disponíveis (/help)."


class GeminiProvider(AIProvider):
    """Provedor Google Gemini"""
    
    def __init__(self):
        self.api_key = settings.GEMINI_API_KEY
        if not self.api_key:
            logger.warning("GEMINI_API_KEY não configurado")
    
    async def generate_response(self, message: str, context: Optional[Dict] = None) -> str:
        """Gera resposta usando Google Gemini"""
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            
            system_instruction = """Você é um assistente jurídico especializado da Genesys Tecnologia.
            Forneça respostas precisas, educadas e profissionais sobre questões jurídicas brasileiras.
            Se não tiver certeza, admita e recomende consultar um advogado.
            Seja conciso e objetivo nas respostas."""
            
            model = genai.GenerativeModel(
                'gemini-2.5-flash',
                system_instruction=system_instruction
            )
            
            response = model.generate_content(message)
            return response.text
            
        except Exception as e:
            logger.error(f"Erro ao chamar Gemini: {e}")
            return self._fallback_response(message)
    
    def _fallback_response(self, message: str) -> str:
        """Resposta fallback quando Gemini falha"""
        return "⚠️ No momento estou tendo dificuldades técnicas. Por favor, tente novamente ou use os comandos disponíveis (/help)."


class AIService:
    """Serviço principal de IA para o bot"""
    
    def __init__(self):
        # Priorizar Gemini (mais barato), fallback para OpenAI
        if settings.GEMINI_API_KEY:
            self.provider = GeminiProvider()
            logger.info("Usando Google Gemini como provedor de IA")
        elif settings.OPENAI_API_KEY:
            self.provider = OpenAIProvider()
            logger.info("Usando OpenAI como provedor de IA")
        else:
            self.provider = None
            logger.warning("Nenhum provedor de IA configurado")
    
    async def process_message(self, message: str, context: Optional[Dict] = None) -> str:
        """
        Processa uma mensagem e retorna resposta gerada por IA
        
        Args:
            message: Mensagem do usuário
            context: Contexto adicional (opcional)
        
        Returns:
            Resposta gerada pela IA
        """
        if not self.provider:
            return self._default_response(message)
        
        try:
            response = await self.provider.generate_response(message, context)
            logger.info(f"IA processou mensagem: {message[:50]}...")
            return response
            
        except Exception as e:
            logger.error(f"Erro ao processar mensagem com IA: {e}")
            return self._default_response(message)
    
    def _default_response(self, message: str) -> str:
        """Resposta padrão quando não há IA disponível"""
        # Respostas inteligentes básicas sem IA
        message_lower = message.lower()
        
        if any(p in message_lower for p in ['jurisprudência', 'decisão', 'acórdão', 'precedente']):
            return "🔍 **Busca de Jurisprudência**\n\nEstou configurando a busca inteligente de jurisprudência. Use o comando /buscar quando estiver pronto para usar essa funcionalidade!"
        
        elif any(p in message_lower for p in ['prazo', 'vencimento', 'processo']):
            return "📅 **Prazos Processuais**\n\nUse o comando /prazos para ver seus prazos pendentes ou /alerta para configurar notificações automáticas!"
        
        elif any(p in message_lower for p in ['contato', 'suporte', 'ajuda']):
            return "💬 **Contato Genesys**\n\n📧 Email: contato@genesys-tecnologia.com.br\n📱 WhatsApp: +55 34 99826-4603\n🌐 Site: https://genesys-tecnologia.com.br"
        
        else:
            return "🤖 **Genesys IA Jurídica**\n\nPara ativar respostas inteligentes com IA, configure sua API key:\n• OPENAI_API_KEY ou\n• GEMINI_API_KEY\n\nUse /help para ver comandos disponíveis!"


# Instância global do serviço de IA
ai_service = AIService()

