"""
Serviço de busca de jurisprudência com IA
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from typing import Dict, List
from shared.config.settings import settings
from shared.utils.logger import bot_telegram_logger as logger
from services.ia_service import ai_service


class JurisprudenciaService:
    """Serviço de busca de jurisprudência"""
    
    def __init__(self):
        self.ia_service = ai_service
    
    async def buscar_jurisprudencia(self, query: str) -> str:
        """
        Busca jurisprudência usando IA
        
        Args:
            query: Consulta jurídica do usuário
        
        Returns:
            Resposta formatada com jurisprudência
        """
        try:
            # Prompt específico para jurisprudência
            prompt = f"""Você é um assistente jurídico especializado em jurisprudência brasileira.

Busque informações sobre: {query}

Forneça:
1. A definição/contexto jurídico
2. Principais precedentes relevantes
3. Jurisprudência dominante dos tribunais
4. Fundamento legal

Seja objetivo e cite fontes quando possível."""

            # Usar IA para gerar resposta
            response = await self.ia_service.process_message(prompt)
            
            # Formatar resposta (sem Markdown complexo para evitar erros)
            resposta_formatada = f"""🔍 BUSCA DE JURISPRUDÊNCIA

Consulta: {query}

{response}

---
💡 Esta resposta é baseada em jurisprudência consolidada. Sempre consulte um advogado para orientação específica."""

            logger.info(f"Busca de jurisprudência realizada: {query}")
            return resposta_formatada
            
        except Exception as e:
            logger.error(f"Erro ao buscar jurisprudência: {e}")
            return f"""🔍 **Busca de Jurisprudência**

**Consulta:** {query}

⚠️ No momento não consigo acessar a base de jurisprudência.

Por favor, tente mais tarde ou consulte diretamente:
• STF: https://jurisprudência.stf.jus.br
• STJ: https://sitar.stj.justica.gov.br
• Tribunais Regionais"""


# Instância global
jurisprudencia_service = JurisprudenciaService()

