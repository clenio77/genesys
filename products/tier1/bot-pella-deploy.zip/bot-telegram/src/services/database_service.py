"""
Serviço para interagir com banco de dados
"""

import sys
from pathlib import Path
from typing import Optional, List, Dict
from datetime import datetime

# Adiciona o diretório pai ao path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from sqlalchemy.orm import Session
from sqlalchemy import desc
from shared.config.database import get_db
from shared.database.models import User, Chat, Prazo, Notificacao, ConsultaJurisprudencia
from shared.utils.logger import bot_telegram_logger as logger


class DatabaseService:
    """Serviço para operações de banco de dados"""
    
    def get_or_create_user(self, telegram_id: int, username: str, full_name: str) -> User:
        """Busca ou cria um usuário"""
        db: Session = next(get_db())
        
        try:
            user = db.query(User).filter(User.telegram_id == telegram_id).first()
            
            if not user:
                user = User(
                    telegram_id=telegram_id,
                    name=full_name,
                    role="user",
                    alerta_canal="telegram",  # Default
                    alerta_intervalo_dias=3,  # Default
                    alerta_ativo=True  # Default
                )
                db.add(user)
                db.commit()
                db.refresh(user)
                logger.info(f"Usuário criado: {telegram_id} - {full_name}")
            else:
                # Atualizar nome se mudou
                if user.name != full_name:
                    user.name = full_name
                    db.commit()
                    db.refresh(user)
            
            return user
            
        except Exception as e:
            logger.error(f"Erro ao buscar/criar usuário: {e}")
            db.rollback()
            raise
        finally:
            db.close()
    
    def save_chat(self, user_id: int, message: str, response: str, metadata: Optional[Dict] = None):
        """Salva conversa no histórico"""
        db: Session = next(get_db())
        
        try:
            chat = Chat(
                user_id=user_id,
                service="telegram",
                message=message,
                response=response,
                metadata=metadata
            )
            db.add(chat)
            db.commit()
            
        except Exception as e:
            logger.error(f"Erro ao salvar chat: {e}")
            db.rollback()
        finally:
            db.close()
    
    def get_user_prazos(self, user_id: int) -> List[Prazo]:
        """Busca prazos do usuário"""
        db: Session = next(get_db())
        
        try:
            prazos = db.query(Prazo).filter(
                Prazo.user_id == user_id,
                Prazo.status == "pendente"
            ).order_by(desc(Prazo.data_vencimento)).limit(10).all()
            
            return prazos
            
        except Exception as e:
            logger.error(f"Erro ao buscar prazos: {e}")
            return []
        finally:
            db.close()
    
    def get_recent_chats(self, user_id: int, limit: int = 5) -> List[Dict]:
        """Busca conversas recentes do usuário"""
        db: Session = next(get_db())
        
        try:
            chats = db.query(Chat).filter(
                Chat.user_id == user_id
            ).order_by(desc(Chat.created_at)).limit(limit).all()
            
            return [{
                "message": chat.message,
                "response": chat.response,
                "created_at": chat.created_at
            } for chat in chats]
            
        except Exception as e:
            logger.error(f"Erro ao buscar chats: {e}")
            return []
        finally:
            db.close()
    
    def save_jurisprudencia_query(self, user_id: int, query: str, results: Dict):
        """Salva consulta de jurisprudência"""
        db: Session = next(get_db())
        
        try:
            consulta = ConsultaJurisprudencia(
                user_id=user_id,
                query=query,
                results=results,
                service="telegram"
            )
            db.add(consulta)
            db.commit()
            
        except Exception as e:
            logger.error(f"Erro ao salvar consulta de jurisprudência: {e}")
            db.rollback()
        finally:
            db.close()


# Instância global
db_service = DatabaseService()

