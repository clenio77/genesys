"""
Serviços do bot
"""

