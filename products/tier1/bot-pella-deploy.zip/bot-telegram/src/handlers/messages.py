"""
Handlers para mensagens de texto do bot
"""

import sys
from pathlib import Path

# Adiciona o diretório pai ao path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from telegram import Update
from telegram.ext import ContextTypes
from shared.utils.logger import bot_telegram_logger as logger
from services.ia_service import ai_service
from services.database_service import db_service


def sanitize_text(text: str) -> str:
    """
    Sanitiza texto para evitar problemas com Markdown
    Remove ou escapa caracteres problemáticos
    """
    if not text:
        return ""
    # Escapa caracteres especiais do Markdown que podem causar problemas
    text = text.replace("_", "\\_")
    text = text.replace("*", "\\*")
    text = text.replace("[", "\\[")
    text = text.replace("]", "\\]")
    text = text.replace("`", "\\`")
    return text


def split_message(text: str, max_length: int = 3900) -> list:
    """
    Divide mensagem longa em múltiplas partes (mensagens separadas)
    Tenta cortar em pontos lógicos (fim de parágrafo, frase, etc.)
    
    Args:
        text: Texto completo a ser dividido
        max_length: Tamanho máximo por parte (3900 para margem de segurança)
    
    Returns:
        Lista de strings, cada uma será enviada como mensagem separada
    """
    if not text:
        return [""]
    
    # Se cabe em uma mensagem, retorna sem dividir
    if len(text) <= max_length:
        return [text]
    
    parts = []
    current_pos = 0
    text_len = len(text)
    
    while current_pos < text_len:
        remaining = text_len - current_pos
        
        # Se o que resta cabe em uma mensagem, pega tudo
        if remaining <= max_length:
            parts.append(text[current_pos:].strip())
            break
        
        # Buscar melhor ponto de corte dentro do limite
        search_end = current_pos + max_length - 100  # Margem para cabeçalho
        chunk = text[current_pos:search_end]
        
        # Ordem de preferência para pontos de corte (mais lógicos primeiro)
        cut_pos = -1
        cut_offset = 0
        
        # 1. Parágrafo duplo (melhor opção)
        pos = chunk.rfind("\n\n")
        if pos > max_length * 0.4:  # Só se não for muito no início
            cut_pos = pos
            cut_offset = 2
        # 2. Quebra de linha simples
        elif chunk.rfind("\n") > max_length * 0.5:
            pos = chunk.rfind("\n")
            cut_pos = pos
            cut_offset = 1
        # 3. Fim de frase (ponto + espaço)
        elif chunk.rfind(". ") > max_length * 0.5:
            pos = chunk.rfind(". ")
            cut_pos = pos
            cut_offset = 2
        # 4. Qualquer ponto
        elif chunk.rfind(".") > max_length * 0.6:
            pos = chunk.rfind(".")
            cut_pos = pos
            cut_offset = 1
        # 5. Vírgula
        elif chunk.rfind(", ") > max_length * 0.7:
            pos = chunk.rfind(", ")
            cut_pos = pos
            cut_offset = 2
        # 6. Último recurso: corta no limite
        else:
            cut_pos = max_length - 100
            cut_offset = 0
        
        # Extrair esta parte
        end_pos = current_pos + cut_pos + cut_offset
        part = text[current_pos:end_pos].strip()
        
        if part:  # Só adiciona se não estiver vazio
            parts.append(part)
        
        current_pos = end_pos
        
        # Proteção contra loop infinito
        if cut_pos <= 0:
            # Força corte
            parts.append(text[current_pos:current_pos + max_length - 100].strip())
            current_pos += max_length - 100
    
    # Se dividiu em múltiplas partes, adiciona numeração
    if len(parts) > 1:
        numbered = []
        total = len(parts)
        for i, part in enumerate(parts, 1):
            header = f"📄 Parte {i}/{total}\n\n"
            numbered.append(header + part)
        return numbered
    
    return parts


async def safe_reply_text(update: Update, text: str, use_markdown: bool = True):
    """
    Envia mensagem de texto com tratamento de erros de parsing
    Se a mensagem for muito longa, divide em múltiplas mensagens separadas
    Tenta Markdown primeiro, depois HTML, depois texto plano
    
    Args:
        update: Update do Telegram
        text: Texto a ser enviado
        use_markdown: Se deve tentar usar Markdown
    """
    # Dividir em partes se necessário
    parts = split_message(text)
    total_parts = len(parts)
    
    logger.info(f"📤 Enviando mensagem em {total_parts} parte(s)")
    
    for i, part in enumerate(parts, 1):
        logger.debug(f"Enviando parte {i}/{total_parts} ({len(part)} caracteres)")
        
        if use_markdown:
            try:
                # Tenta enviar com Markdown
                sanitized = sanitize_text(part)
                await update.message.reply_text(sanitized, parse_mode="Markdown")
                logger.debug(f"✅ Parte {i}/{total_parts} enviada com Markdown")
                continue
            except Exception as e:
                logger.warning(f"Erro ao enviar parte {i}/{total_parts} com Markdown: {e}. Tentando HTML...")
                try:
                    # Tenta HTML
                    await update.message.reply_text(part, parse_mode="HTML")
                    logger.debug(f"✅ Parte {i}/{total_parts} enviada com HTML")
                    continue
                except Exception as e2:
                    logger.warning(f"Erro ao enviar parte {i}/{total_parts} com HTML: {e2}. Enviando como texto plano...")
        
        # Fallback para texto plano
        try:
            await update.message.reply_text(part, parse_mode=None)
            logger.debug(f"✅ Parte {i}/{total_parts} enviada como texto plano")
        except Exception as e3:
            logger.error(f"❌ Erro ao enviar parte {i}/{total_parts} como texto plano: {e3}")
            
            # Último recurso: truncar esta parte drasticamente
            if len(part) > 3000:
                truncated = part[:3000] + "\n\n⚠️ ... (mensagem muito longa, parte truncada)"
                try:
                    await update.message.reply_text(truncated, parse_mode=None)
                    logger.warning(f"⚠️ Parte {i}/{total_parts} foi truncada")
                except Exception:
                    logger.error(f"❌ Falha total ao enviar parte {i}/{total_parts}")
    
    logger.info(f"✅ Mensagem completa enviada ({total_parts} parte(s))")


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Handler principal para mensagens de texto
    
    Processa mensagens em linguagem natural e usa IA para gerar respostas
    """
    user_message = update.message.text
    user_id = update.effective_user.id
    username = update.effective_user.username or "Unknown"
    full_name = update.effective_user.full_name or "User"
    
    logger.info(f"Usuário {user_id} ({username}) enviou: {user_message}")
    
    # Mostrar indicador de digitação (de forma segura - não crítico se falhar)
    try:
        await update.message.chat.send_action("typing")
        logger.debug("✅ Indicador de digitação enviado")
    except Exception as e:
        # Ignorar timeouts - não é crítico se falhar
        logger.debug(f"Erro ao enviar indicador de digitação (ignorando): {type(e).__name__}")
        pass
    
    # Verificar se está aguardando número de processo
    if context.user_data.get('aguardando_processo', False):
        try:
            from services.cnj_service import cnj_service
            
            # Limpar flag
            context.user_data['aguardando_processo'] = False
            
            # Mensagem de status
            logger.info("📝 Consultando processo na API CNJ...")
            status_msg = await update.message.reply_text("🔍 *Consultando processo...*", parse_mode="Markdown")
            
            # Consultar processo (com fallback automático)
            dados = cnj_service.consultar_processo(user_message)
            
            # Se retornou erro mas não é None, pode ter sido encontrado em outra fonte
            if dados and not dados.get('erro'):
                # Formatar resposta
                resposta = cnj_service.formatar_resposta_processo(dados)
            elif dados and dados.get('erro'):
                # Processo não encontrado em nenhuma fonte, tentar Playwright como último recurso
                try:
                    from services.playwright_extractor import tribunal_extractor
                    
                    # Atualizar status
                    await status_msg.edit_text("🔍 *Buscando diretamente no site do tribunal...*", parse_mode="Markdown")
                    
                    # Extrair alias do tribunal do número do processo
                    # Formato: NNNNNNN-DD.AAAA.J.TR.OOOO
                    partes = user_message.replace('-', '.').split('.')
                    if len(partes) >= 4:
                        codigo_tribunal = partes[2]  # Código do tribunal
                        tribunal_alias = f"tj{codigo_tribunal}"
                    else:
                        tribunal_alias = "tj26"  # Default: TJMG
                    
                    # Tentar extrair com Playwright
                    async with tribunal_extractor:
                        dados_playwright = await tribunal_extractor.extrair_processo_geral(user_message, tribunal_alias)
                    
                    if dados_playwright:
                        resposta = cnj_service.formatar_resposta_processo(dados_playwright)
                    else:
                        resposta = """⚠️ **Processo não encontrado**

Não foi possível localizar este processo em nenhuma fonte:
• API Pública do CNJ
• Base de dados local (Kermartin)
• Site do tribunal (scraping)

**Possíveis causas:**
• Número de processo inválido ou incorreto
• Processo ainda não indexado
• Problema temporário nos sistemas

💡 Verifique o número e tente novamente."""
                except Exception as e:
                    logger.error(f"Erro ao usar Playwright: {e}")
                    resposta = """⚠️ **Erro ao consultar processo**

Não foi possível acessar os sistemas no momento.

**Tentativas realizadas:**
• API Pública do CNJ
• Base de dados local
• Site do tribunal

💡 Verifique o número e tente novamente mais tarde."""
            else:
                resposta = """⚠️ **Erro ao consultar processo**

Não foi possível acessar a API do CNJ no momento.

**Possíveis causas:**
• Número de processo inválido
• Problema na API do CNJ
• Processo não encontrado

💡 Verifique o número e tente novamente."""
            
            # Deletar mensagem de status e enviar resposta
            try:
                await status_msg.delete()
                logger.debug("✅ Mensagem de status deletada")
            except Exception as e:
                logger.warning(f"Não foi possível deletar mensagem de status: {e}")
            
            await safe_reply_text(update, resposta, use_markdown=True)
            return
            
        except Exception as e:
            logger.error(f"Erro ao consultar processo: {e}")
            context.user_data['aguardando_processo'] = False
            await safe_reply_text(update, "⚠️ Ocorreu um erro ao consultar o processo. Tente novamente.", use_markdown=False)
            return
    
    # Verificar se está aguardando nome do magistrado
    if context.user_data.get('aguardando_magistrado', False):
        try:
            from services.kermartin_service import kermartin_service
            
            # Limpar flag
            context.user_data['aguardando_magistrado'] = False
            
            # Mensagem de status
            logger.info(f"📝 Buscando magistrado: {user_message}")
            status_msg = await update.message.reply_text("🔍 *Buscando magistrado...*", parse_mode="Markdown")
            
            # Buscar magistrado
            magistrado = kermartin_service.buscar_magistrado(user_message)
            
            if magistrado:
                # Formatar resposta
                dados = magistrado.get('dados', {}) or magistrado.get('metadata', {})
                nome = dados.get('magistrado') or dados.get('nome_magistrado') or magistrado.get('nome_publico', 'N/A')
                tribunal = dados.get('tribunal') or magistrado.get('tribunal', 'N/A')
                comarca = dados.get('comarca') or magistrado.get('comarca', 'N/A')
                vara = dados.get('vara') or magistrado.get('vara', 'N/A')
                total_julgados = dados.get('total_julgados', 0)
                
                resposta = f"""⚖️ **Perfil do Magistrado**

**Nome:** {nome}
**Tribunal:** {tribunal}
**Comarca:** {comarca}
**Vara:** {vara}

**Estatísticas:**
📊 Total de julgados: {total_julgados}

**Julgados Recentes:**
"""
                
                # Adicionar últimos 3 julgados
                julgados = dados.get('julgados_consolidados', [])[:3]
                if julgados:
                    for i, julgado in enumerate(julgados, 1):
                        numero = julgado.get('numero', 'N/A')
                        data = julgado.get('data', 'N/A')
                        resposta += f"\n{i}. `{numero}`\n   📅 {data}"
                else:
                    resposta += "\nNenhum julgado recente disponível."
                
                resposta += "\n\n💡 Dados fornecidos pela base Kermartin"
            else:
                # Listar magistrados disponíveis
                magistrados = kermartin_service.listar_magistrados_disponiveis()
                if magistrados:
                    resposta = f"""⚠️ **Magistrado não encontrado**

Não encontrei um magistrado com o nome: **{user_message}**

**Magistrados disponíveis:**
"""
                    for mag in magistrados[:10]:  # Primeiros 10
                        resposta += f"• {mag}\n"
                    
                    if len(magistrados) > 10:
                        resposta += f"\n... e mais {len(magistrados) - 10} magistrados."
                    
                    resposta += "\n\n💡 Tente buscar usando parte do nome."
                else:
                    resposta = f"""⚠️ **Magistrado não encontrado**

Não encontrei um magistrado com o nome: **{user_message}**

A base de conhecimento ainda não possui dados deste magistrado.

💡 Tente buscar por outro nome ou use /help para mais informações."""
            
            # Deletar mensagem de status e enviar resposta
            try:
                await status_msg.delete()
                logger.debug("✅ Mensagem de status deletada")
            except Exception as e:
                logger.warning(f"Não foi possível deletar mensagem de status: {e}")
            
            await safe_reply_text(update, resposta, use_markdown=True)
            return
            
        except Exception as e:
            logger.error(f"Erro ao buscar magistrado: {e}")
            context.user_data['aguardando_magistrado'] = False
            await safe_reply_text(update, "⚠️ Ocorreu um erro ao buscar o magistrado. Tente novamente.", use_markdown=False)
            return
    
    # Verificar se está em modo de busca de jurisprudência
    if context.user_data.get('aguardando_busca', False):
        try:
            from services.jurisprudencia_service import jurisprudencia_service
            
            # Limpar flag
            context.user_data['aguardando_busca'] = False
            
            # Mensagem de status
            logger.info("📝 Enviando mensagem de status: Analisando jurisprudência...")
            status_msg = await update.message.reply_text("🔍 *Analisando sua consulta jurídica...*", parse_mode="Markdown")
            logger.debug("✅ Mensagem de status enviada")
            
            # Buscar jurisprudência
            resposta = await jurisprudencia_service.buscar_jurisprudencia(user_message)
            
            # Deletar mensagem de status e enviar resposta
            try:
                await status_msg.delete()
                logger.debug("✅ Mensagem de status deletada")
            except Exception as e:
                logger.warning(f"Não foi possível deletar mensagem de status: {e}")
            
            # Enviar resposta com tratamento de erros
            await safe_reply_text(update, resposta, use_markdown=True)
            return
            
        except Exception as e:
            logger.error(f"Erro ao buscar jurisprudência: {e}")
            # Continuar processamento normal
    
    # Criar/buscar usuário no banco
    try:
        user = db_service.get_or_create_user(user_id, username, full_name)
    except Exception as e:
        logger.error(f"Erro ao buscar/criar usuário: {e}")
        user = None
    
    # Processar mensagem com IA
    try:
        # Mensagem de status
        logger.info("📝 Enviando mensagem de status: Processando com IA...")
        status_msg = await update.message.reply_text("🤖 *Processando com IA...*", parse_mode="Markdown")
        logger.debug("✅ Mensagem de status enviada")
        
        response = await ai_service.process_message(user_message)
        
        # Salvar conversa no banco
        if user:
            try:
                db_service.save_chat(
                    user_id=user.id,
                    message=user_message,
                    response=response,
                    metadata={
                        "telegram_id": user_id,
                        "username": username
                    }
                )
            except Exception:
                pass  # Ignora se DB não disponível
        
        # Deletar mensagem de status e enviar resposta
        try:
            await status_msg.delete()
            logger.debug("✅ Mensagem de status deletada")
        except Exception as e:
            logger.warning(f"Não foi possível deletar mensagem de status: {e}")
        
        # Enviar resposta com tratamento de erros
        await safe_reply_text(update, response, use_markdown=True)
        
    except Exception as e:
        logger.error(f"Erro ao processar mensagem: {e}")
        
        # Resposta de fallback
        fallback_response = "⚠️ Ops! Tive um problema ao processar sua mensagem.\n\n" \
                           "Por favor, tente novamente ou use os comandos disponíveis (/help)"
        
        await update.message.reply_text(fallback_response)

