"""Handlers para o Bot de Telegram"""

