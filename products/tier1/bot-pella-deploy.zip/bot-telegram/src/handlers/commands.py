"""
Handlers para comandos do bot
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes, CallbackQueryHandler
from telegram.constants import ParseMode

from shared.utils.logger import bot_telegram_logger as logger


async def safe_send_typing(chat):
    """
    Envia indicador de digitação de forma segura, ignorando timeouts
    Não falha o comando se houver problema de conexão
    """
    try:
        await chat.send_action("typing")
    except Exception as e:
        # Ignorar timeouts e outros erros de conexão - não é crítico
        logger.debug(f"Erro ao enviar indicador de digitação (ignorando): {type(e).__name__}")
        pass


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /help"""
    await safe_send_typing(update.message.chat)
    
    help_text = """
📚 **Comandos Disponíveis:**

/start - Reiniciar o bot
/help - Ver esta ajuda
/buscar - Buscar jurisprudência
/prazos - Ver prazos processuais pendentes
/alerta - Configurar alertas
/processo - Consultar status de processo (API CNJ + base local)
/magistrado - Buscar perfil de magistrado
/config - Configurações
/perfil - Meu perfil

💡 **Dica:** Você também pode fazer perguntas em linguagem natural e eu tentarei ajudar!
"""
    await update.message.reply_text(help_text, parse_mode=ParseMode.MARKDOWN)


async def cmd_buscar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /buscar - Buscar jurisprudência"""
    await safe_send_typing(update.message.chat)
    
    try:
        from services.jurisprudencia_service import jurisprudencia_service
        
        # Armazenar o estado de busca
        context.user_data['aguardando_busca'] = True
        
        await update.message.reply_text(
            "🔍 **Busca de Jurisprudência**\n\n"
            "Envie o tema ou questão jurídica que deseja buscar.\n"
            "**Exemplos:**\n"
            "• 'indenização por danos morais'\n"
            "• 'precedentes sobre CLT'\n"
            "• 'jurisprudência trabalhista'\n\n"
            "💡 Eu buscarei em nossa base de decisões com IA!",
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        logger.error(f"Erro no comando /buscar: {e}")
        await update.message.reply_text(
            "🔍 Busca de jurisprudência. Digite sua consulta jurídica.",
            parse_mode=ParseMode.MARKDOWN
        )


async def cmd_prazos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /prazos - Listar prazos pendentes"""
    # Mostrar indicador de digitação
    await safe_send_typing(update.message.chat)
    
    try:
        from services.prazos_service import prazos_service
        from services.database_service import db_service
        from shared.config.database import get_db
        from shared.database.models import User
        
        user_id = update.effective_user.id
        
        try:
            # Buscar usuário
            db = next(get_db())
            user = db.query(User).filter(User.telegram_id == user_id).first()
            db.close()
            
            if user:
                # Buscar prazos reais do banco
                prazos = db_service.get_user_prazos(user.id)
                resposta = prazos_service.formatar_prazos(prazos)
            else:
                # Usar prazos de exemplo
                resposta = prazos_service.criar_prazo_exemplo(user_id)
            
            await update.message.reply_text(resposta, parse_mode=ParseMode.MARKDOWN)
            
        except Exception as db_error:
            logger.warning(f"Banco de dados não disponível: {db_error}")
            # Mostrar prazos de exemplo
            resposta = prazos_service.criar_prazo_exemplo(user_id)
            await update.message.reply_text(resposta, parse_mode=ParseMode.MARKDOWN)
            
    except Exception as e:
        logger.error(f"Erro ao buscar prazos: {e}")
        await update.message.reply_text(
            "📅 **Seus Prazos Processuais**\n\n"
            "⚠️ Não foi possível acessar seus prazos agora.\n"
            "Use /alerta para configurar notificações.",
            parse_mode=ParseMode.MARKDOWN
        )


async def cmd_alerta(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /alerta - Configurar alertas"""
    await safe_send_typing(update.message.chat)
    
    try:
        # Buscar preferências atuais do usuário
        from services.alertas_service import alertas_service
        from services.database_service import db_service
        
        user = db_service.get_or_create_user(
            update.effective_user.id,
            update.effective_user.username or "User",
            update.effective_user.full_name or "User"
        )
        
        prefs = alertas_service.get_user_alert_preferences(user.id)
        
        # Montar mensagem com status atual
        if prefs:
            canal_emoji = "📧" if prefs["canal"] == "email" else "📱"
            canal_nome = prefs["canal"].upper()
            intervalo = prefs["intervalo_dias"]
            status = "✅ Ativo" if prefs["ativo"] else "❌ Desativado"
            
            status_text = f"""⚙️ **Configuração de Alertas de Prazos**

**Status Atual:**
{canal_emoji} Canal: {canal_nome}
⏰ Intervalo: {intervalo} dias antes
🔔 Status: {status}

**Escolha como deseja receber alertas:**"""
        else:
            status_text = """⚙️ **Configuração de Alertas de Prazos**

Escolha como deseja receber seus alertas de prazos processuais:"""
        
    except Exception as e:
        logger.error(f"Erro ao buscar preferências: {e}")
        status_text = """⚙️ **Configuração de Alertas de Prazos**

Escolha como deseja receber seus alertas de prazos processuais:"""
    
    keyboard = [
        [
            InlineKeyboardButton("📧 Via Email", callback_data="alerta_email"),
            InlineKeyboardButton("📱 Via Telegram", callback_data="alerta_telegram")
        ],
        [
            InlineKeyboardButton("⏰ 7 dias antes", callback_data="intervalo_7"),
            InlineKeyboardButton("⏰ 3 dias antes", callback_data="intervalo_3"),
            InlineKeyboardButton("⏰ 1 dia antes", callback_data="intervalo_1")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        status_text,
        reply_markup=reply_markup,
        parse_mode=ParseMode.MARKDOWN
    )


async def cmd_processo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /processo - Consultar processo via API CNJ"""
    await safe_send_typing(update.message.chat)
    
    # Marcar que está aguardando número do processo
    context.user_data['aguardando_processo'] = True
    
    await update.message.reply_text(
        "⚖️ **Consulta de Processo**\n\n"
        "🔍 Envie o número do processo no formato CNJ:\n\n"
        "**Formato:** NNNNNNN-DD.AAAA.J.TR.OOOO\n\n"
        "**Exemplo:**\n"
        "`0001234-56.2024.8.26.0100`\n\n"
        "💡 Eu consultarei na API Pública do CNJ e te mostrarei:\n"
        "• Status do processo\n"
        "• Última movimentação\n"
        "• Dados principais\n\n"
        "📝 Envie o número agora:",
        parse_mode=ParseMode.MARKDOWN
    )


async def cmd_magistrado(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /magistrado - Buscar perfil de magistrado"""
    await safe_send_typing(update.message.chat)
    
    # Marcar que está aguardando nome do magistrado
    context.user_data['aguardando_magistrado'] = True
    
    await update.message.reply_text(
        "⚖️ **Consulta de Magistrado**\n\n"
        "🔍 Envie o nome do magistrado que deseja buscar:\n\n"
        "**Exemplos:**\n"
        "• Dimas Borges de Paula\n"
        "• Rui Magalhães\n"
        "• Paulo Caixeta\n\n"
        "💡 Vou buscar na base de conhecimento:\n"
        "• Perfil completo\n"
        "• Estatísticas de julgados\n"
        "• Especialização\n"
        "• Histórico de decisões\n\n"
        "📝 Envie o nome agora:",
        parse_mode=ParseMode.MARKDOWN
    )


async def cmd_config(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /config - Configurações"""
    await safe_send_typing(update.message.chat)
    
    config_text = """
⚙️ **Configurações**

🔔 Notificações: Ativadas
📧 Email: cadastrado
📱 Telegram: Ativo
🌐 Idioma: Português (BR)

Use os botões abaixo para alterar:
"""
    
    keyboard = [
        [
            InlineKeyboardButton("🔔 Notificações", callback_data="config_notif"),
            InlineKeyboardButton("📧 Email", callback_data="config_email")
        ],
        [
            InlineKeyboardButton("📱 Telegram", callback_data="config_telegram"),
            InlineKeyboardButton("🌐 Idioma", callback_data="config_idioma")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        config_text,
        reply_markup=reply_markup,
        parse_mode=ParseMode.MARKDOWN
    )


async def cmd_perfil(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /perfil - Ver perfil"""
    await safe_send_typing(update.message.chat)
    
    user = update.effective_user
    
    await update.message.reply_text(
        f"👤 **Meu Perfil**\n\n"
        f"🆔 ID: {user.id}\n"
        f"👤 Nome: {user.full_name}\n"
        f"@ {user.username or 'N/A'}\n\n"
        f"💳 Plano: Gratuito\n"
        f"📊 Consultas este mês: 0\n",
        parse_mode=ParseMode.MARKDOWN
    )


async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler para callbacks dos botões inline"""
    query = update.callback_query
    await query.answer()
    
    user_id = update.effective_user.id
    
    try:
        # Importar serviço de alertas
        from services.alertas_service import alertas_service
        from services.database_service import db_service
        
        # Buscar ou criar usuário
        try:
            user = db_service.get_or_create_user(
                user_id,
                update.effective_user.username or "User",
                update.effective_user.full_name or "User"
            )
        except Exception as e:
            logger.error(f"Erro ao buscar/criar usuário: {e}")
            await query.edit_message_text(
                "⚠️ Erro ao processar. Tente novamente."
            )
            return
        
        if query.data.startswith("alerta_"):
            # Configurar alerta via canal selecionado
            canal = query.data.split("_")[1]
            
            # Mapear valores
            canal_map = {
                "email": "email",
                "telegram": "telegram",
                "custom": "telegram"  # default para custom
            }
            canal_preferido = canal_map.get(canal, "telegram")
            
            # Salvar preferência no banco
            sucesso = alertas_service.update_alert_channel(user.id, canal_preferido)
            
            if sucesso:
                logger.info(f"Usuário {user_id} configurou alertas via {canal_preferido}")
                emoji = "📧" if canal_preferido == "email" else "📱"
                
                await query.edit_message_text(
                    f"✅ **Alerta configurado!**\n\n"
                    f"{emoji} Você receberá notificações via {canal_preferido.upper()}\n\n"
                    f"💡 Use /alerta novamente para ajustar o intervalo."
                )
            else:
                await query.edit_message_text(
                    "⚠️ Erro ao salvar preferência. Tente novamente."
                )
        
        elif query.data.startswith("intervalo_"):
            # Configurar intervalo de alertas
            try:
                dias = int(query.data.split("_")[1])
                
                # Validar intervalo
                if dias not in [1, 3, 7]:
                    dias = 3  # default
                
                # Salvar intervalo no banco
                sucesso = alertas_service.update_alert_interval(user.id, dias)
                
                if sucesso:
                    logger.info(f"Usuário {user_id} configurou intervalo de {dias} dias")
                    
                    await query.edit_message_text(
                        f"✅ **Intervalo configurado!**\n\n"
                        f"⏰ Você receberá alertas **{dias} dias** antes do vencimento.\n\n"
                        f"📋 Configuração completa!\n"
                        f"💡 Use /alerta para alterar novamente."
                    )
                else:
                    await query.edit_message_text(
                        "⚠️ Erro ao salvar intervalo. Tente novamente."
                    )
            except ValueError:
                await query.edit_message_text(
                    "⚠️ Intervalo inválido. Use /alerta novamente."
                )
        
        elif query.data.startswith("config_"):
            # Configurações gerais
            config_type = query.data.split("_")[1]
            
            if config_type == "notif":
                await query.edit_message_text(
                    "🔔 **Configurações de Notificações**\n\n"
                    "Escolha a frequência:\n\n"
                    "📱 Todos os alertas\n"
                    "🔴 Apenas urgentes\n"
                    "📅 Diário resumido\n"
                )
            
            elif config_type == "email":
                await query.edit_message_text(
                    "📧 **Configuração de Email**\n\n"
                    "Digite seu email no formato:\n"
                    "email@exemplo.com\n\n"
                    "💡 Enviaremos seus alertas por email."
                )
            
            elif config_type == "telegram":
                await query.edit_message_text(
                    "📱 **Notificações Telegram**\n\n"
                    "✅ Ativadas\n\n"
                    "Você receberá alertas diretamente aqui no Telegram."
                )
            
            elif config_type == "idioma":
                await query.edit_message_text(
                    "🌐 **Idioma**\n\n"
                    "✅ Português (BR)\n\n"
                    "Sempre falaremos em português brasileiro!"
                )
        
        else:
            await query.edit_message_text(
                "⚙️ Opção reconhecida! Em breve teremos mais funcionalidades."
            )
            
    except Exception as e:
        logger.error(f"Erro ao processar callback: {e}")
        await query.edit_message_text(
            "⚠️ Erro ao processar configuração. Tente novamente."
        )


def register_command_handlers(application: Application):
    """Registra todos os command handlers"""
    application.add_handler(CommandHandler("help", cmd_help))
    application.add_handler(CommandHandler("buscar", cmd_buscar))
    application.add_handler(CommandHandler("prazos", cmd_prazos))
    application.add_handler(CommandHandler("alerta", cmd_alerta))
    application.add_handler(CommandHandler("processo", cmd_processo))
    application.add_handler(CommandHandler("magistrado", cmd_magistrado))
    application.add_handler(CommandHandler("config", cmd_config))
    application.add_handler(CommandHandler("perfil", cmd_perfil))
    
    # Callback handler para botões inline
    application.add_handler(CallbackQueryHandler(button_callback))

